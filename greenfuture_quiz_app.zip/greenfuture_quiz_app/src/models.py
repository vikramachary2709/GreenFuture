from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from datetime import datetime

@dataclass
class Question:
    id: str
    topic: str
    category: str
    question_text: str
    options: List[str]
    correct_option_index: int
    explanation: str = ""
    difficulty: str = "Medium"  # Easy, Medium, Hard

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Question':
        return cls(
            id=str(data.get("id", "")),
            topic=str(data.get("topic", "General")),
            category=str(data.get("category", "General")),
            question_text=str(data.get("question_text", "")),
            options=list(data.get("options", [])),
            correct_option_index=int(data.get("correct_option_index", 0)),
            explanation=str(data.get("explanation", "")),
            difficulty=str(data.get("difficulty", "Medium"))
        )

@dataclass
class QuizAttempt:
    attempt_id: str
    learner_name: str
    topic: str
    score: int
    total_questions: int
    percentage: float
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    answers_details: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'QuizAttempt':
        return cls(
            attempt_id=str(data.get("attempt_id", "")),
            learner_name=str(data.get("learner_name", "Anonymous")),
            topic=str(data.get("topic", "General")),
            score=int(data.get("score", 0)),
            total_questions=int(data.get("total_questions", 0)),
            percentage=float(data.get("percentage", 0.0)),
            timestamp=str(data.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))),
            answers_details=list(data.get("answers_details", []))
        )

@dataclass
class ExecutiveSummary:
    total_attempts: int
    total_learners: int
    overall_average_score: float
    pass_rate: float
    topic_performance: Dict[str, Dict[str, Any]]
    warning_topics: List[str]

import os
import sys
import time
from pathlib import Path

# Add root directory to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.storage import initialize_storage, load_questions, load_attempts, reset_to_seeds, add_question
from src.quiz_engine import (
    get_available_topics,
    get_questions_by_topic,
    search_questions,
    evaluate_quiz_session,
    validate_integer_range,
    sanitize_string_input
)
from src.analytics import calculate_executive_summary, generate_analytics_charts
from src.export_import import export_executive_summary_markdown, export_audit_log_text, bulk_import_questions_csv
from src.models import Question

# ANSI Color codes
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BLUE = "\033[94m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_banner():
    print(f"{CYAN}{BOLD}")
    print("=" * 65)
    print("   🌱 GREENFUTURE PYTHON QUIZ APPLICATION - MENTOR GUIDE CLI 🌱   ")
    print("      Automated Quiz Creation, Scoring & Performance Analytics    ")
    print("=" * 65)
    print(f"{RESET}")

def prompt_menu():
    print(f"\n{BOLD}=== MAIN MENU ==={RESET}")
    print(f"{GREEN}1.{RESET} Take a Topic-Wise Quiz 🎯")
    print(f"{GREEN}2.{RESET} Search & Query Question Records 🔍")
    print(f"{GREEN}3.{RESET} View Executive Analytics & Metrics 📊")
    print(f"{GREEN}4.{RESET} Add New Question Record ➕")
    print(f"{GREEN}5.{RESET} Export Multi-Format Reports 📥")
    print(f"{GREEN}6.{RESET} Bulk Import CSV Questions 📂")
    print(f"{GREEN}7.{RESET} Reset Data to Initial Seed State 🔄")
    print(f"{GREEN}8.{RESET} Exit CLI Interface 🚪")

def cli_take_quiz():
    print(f"\n{BOLD}{CYAN}--- TAKE A TOPIC-WISE QUIZ ---{RESET}")
    topics = get_available_topics()
    if not topics:
        print(f"{RED}No topics available in database.{RESET}")
        return

    print("Available Topics:")
    for idx, t in enumerate(topics, 1):
        print(f"  [{idx}] {t}")

    while True:
        choice = input(f"\nSelect Topic Number (1-{len(topics)}): ").strip()
        valid, val, err = validate_integer_range(choice, 1, len(topics))
        if valid and val is not None:
            selected_topic = topics[val - 1]
            break
        print(f"{RED}Error: {err}{RESET}")

    questions = get_questions_by_topic(selected_topic)
    if not questions:
        print(f"{YELLOW}No questions available for '{selected_topic}'.{RESET}")
        return

    learner_name = input("Enter Learner Name: ").strip()
    learner_name = sanitize_string_input(learner_name, "Anonymous Learner")

    while True:
        num_str = input(f"How many questions to attempt? (1-{len(questions)}): ").strip()
        valid, num_q, err = validate_integer_range(num_str, 1, len(questions))
        if valid and num_q is not None:
            break
        print(f"{RED}Error: {err}{RESET}")

    selected_questions = questions[:num_q]
    user_responses = []

    print(f"\n{GREEN}Starting Quiz on '{selected_topic}' ({num_q} questions)...{RESET}")
    print("-" * 55)

    for idx, q in enumerate(selected_questions, 1):
        print(f"\n{BOLD}Question {idx}/{num_q}:{RESET} {q.question_text}")
        print(f"Difficulty: {YELLOW}{q.difficulty}{RESET} | Category: {CYAN}{q.category}{RESET}")
        
        for o_idx, opt in enumerate(q.options, 1):
            print(f"   [{o_idx}] {opt}")

        while True:
            ans_str = input(f"Select option (1-{len(q.options)}): ").strip()
            v, opt_idx, e = validate_integer_range(ans_str, 1, len(q.options))
            if v and opt_idx is not None:
                selected_idx = opt_idx - 1
                break
            print(f"{RED}Error: {e}{RESET}")

        is_correct = (selected_idx == q.correct_option_index)
        if is_correct:
            print(f"{GREEN}✓ Correct!{RESET}")
        else:
            correct_text = q.options[q.correct_option_index]
            print(f"{RED}✗ Incorrect! Correct answer: [{q.correct_option_index + 1}] {correct_text}{RESET}")

        if q.explanation:
            print(f"{BLUE}Explanation:{RESET} {q.explanation}")

        user_responses.append((q, selected_idx))

    attempt = evaluate_quiz_session(learner_name, selected_topic, user_responses)

    print("\n" + "=" * 50)
    print(f"{BOLD}QUIZ SUMMARY RESULT{RESET}")
    print(f"Learner Name: {attempt.learner_name}")
    print(f"Topic:        {attempt.topic}")
    print(f"Final Score:  {attempt.score} / {attempt.total_questions}")
    print(f"Percentage:   {attempt.percentage}%")

    if attempt.percentage >= 60.0:
        print(f"{GREEN}{BOLD}STATUS: PASS / MASTERY ACHIEVED 🎉{RESET}")
    else:
        print(f"{RED}{BOLD}STATUS: NEEDS REVIEW (Score < 60%) ⚠️{RESET}")
    print("=" * 50)

def cli_search_questions():
    print(f"\n{BOLD}{CYAN}--- SEARCH & QUERY QUESTION RECORDS ---{RESET}")
    kw = input("Enter search keyword (leave blank for all): ").strip()
    
    topics = ["All"] + get_available_topics()
    print("Filter by Topic:")
    for i, t in enumerate(topics):
        print(f"  [{i}] {t}")
    
    t_choice = input(f"Select Topic (0-{len(topics)-1}, default 0): ").strip()
    v, t_idx, _ = validate_integer_range(t_choice, 0, len(topics)-1) if t_choice else (True, 0, "")
    sel_topic = topics[t_idx if (v and t_idx is not None) else 0]

    results = search_questions(keyword=kw, topic="" if sel_topic == "All" else sel_topic)

    print(f"\nFound {len(results)} matching questions:")
    print("-" * 75)
    print(f"{'ID':<8} | {'Topic':<20} | {'Difficulty':<10} | {'Question Snippet':<30}")
    print("-" * 75)
    for q in results[:15]:  # Paginated display
        snippet = q.question_text[:28] + ".." if len(q.question_text) > 30 else q.question_text
        print(f"{q.id:<8} | {q.topic:<20} | {q.difficulty:<10} | {snippet:<30}")
    print("-" * 75)

def cli_analytics_dashboard():
    print(f"\n{BOLD}{CYAN}--- EXECUTIVE ANALYTICS & METRICS DASHBOARD ---{RESET}")
    summary = calculate_executive_summary()

    print("\n" + "=" * 55)
    print(f"Total Quiz Attempts Logged:  {summary.total_attempts}")
    print(f"Total Unique Learners:       {summary.total_learners}")
    print(f"Overall Average Score:       {summary.overall_average_score}%")
    print(f"Overall Pass Rate (>= 60%):  {summary.pass_rate}%")
    print("=" * 55)

    if summary.warning_topics:
        print(f"\n{RED}{BOLD}⚠️ THRESHOLD WARNING FLAGS:{RESET}")
        for wt in summary.warning_topics:
            avg = summary.topic_performance[wt]['average_score']
            print(f"  • {wt}: Average Score {avg}% (Below 60% threshold)")
    else:
        print(f"\n{GREEN}✅ All topics meet or exceed 60% performance threshold.{RESET}")

    print(f"\n{BOLD}Topic Breakdown Table:{RESET}")
    print("-" * 65)
    print(f"{'Topic':<22} | {'Attempts':<8} | {'Avg Score':<10} | {'Status':<15}")
    print("-" * 65)
    for t, stats in summary.topic_performance.items():
        status = f"{RED}Needs Review{RESET}" if stats['needs_review'] else f"{GREEN}Satisfactory{RESET}"
        print(f"{t:<22} | {stats['attempts']:<8} | {stats['average_score']:<9}% | {status}")
    print("-" * 65)

    gen_plot = input("\nGenerate Matplotlib Visual Charts on disk? (y/n): ").strip().lower()
    if gen_plot == 'y':
        generate_analytics_charts(save_to_disk=True)
        print(f"{GREEN}✓ Visual chart exports saved to 'exports/' folder successfully!{RESET}")

def cli_add_question():
    print(f"\n{BOLD}{CYAN}--- ADD NEW QUESTION RECORD ---{RESET}")
    q_id = input("Enter Question ID (e.g. PY011): ").strip() or f"CUSTOM_{int(time.time())}"
    topic = input("Enter Topic (e.g. Python Programming): ").strip() or "General"
    category = input("Enter Category (e.g. Loops): ").strip() or "General"
    question_text = input("Enter Question Text: ").strip()
    
    if not question_text:
        print(f"{RED}Question text cannot be blank. Operation cancelled.{RESET}")
        return

    print("Enter 4 multiple choice options:")
    options = []
    for i in range(1, 5):
        opt = input(f"  Option {i}: ").strip()
        options.append(opt or f"Option {i}")

    print("Select Correct Option Index (1-4):")
    c_choice = input("Choice: ").strip()
    v, c_idx, _ = validate_integer_range(c_choice, 1, 4)
    correct_option_index = (c_idx - 1) if (v and c_idx is not None) else 0

    explanation = input("Enter Explanation (optional): ").strip()
    difficulty = input("Enter Difficulty (Easy / Medium / Hard): ").strip() or "Medium"

    q = Question(
        id=q_id,
        topic=topic,
        category=category,
        question_text=question_text,
        options=options,
        correct_option_index=correct_option_index,
        explanation=explanation,
        difficulty=difficulty
    )

    if add_question(q):
        print(f"{GREEN}✓ Question '{q_id}' added successfully!{RESET}")
    else:
        print(f"{RED}Failed to save question.{RESET}")

def cli_export_reports():
    print(f"\n{BOLD}{CYAN}--- EXPORT MULTI-FORMAT REPORTS ---{RESET}")
    md_path = export_executive_summary_markdown()
    txt_path = export_audit_log_text()
    print(f"{GREEN}✓ Markdown Executive Summary exported to: {md_path}{RESET}")
    print(f"{GREEN}✓ Text Audit Log exported to:              {txt_path}{RESET}")

def cli_bulk_import():
    print(f"\n{BOLD}{CYAN}--- BULK IMPORT CSV QUESTIONS ---{RESET}")
    file_path = input("Enter path to CSV file to import: ").strip()
    if not os.path.exists(file_path):
        print(f"{RED}File not found at '{file_path}'.{RESET}")
        return

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        imported, total, errors = bulk_import_questions_csv(content)
        print(f"\n{GREEN}Imported {imported}/{total} rows successfully.{RESET}")
        if errors:
            print(f"\n{YELLOW}Row Validation Warning Logs:{RESET}")
            for err in errors:
                print(f"  • {err}")
    except Exception as e:
        print(f"{RED}Failed to read CSV file: {e}{RESET}")

def main_cli():
    initialize_storage()
    print_banner()

    while True:
        prompt_menu()
        choice = input("\nSelect Option (1-8): ").strip()
        v, opt, _ = validate_integer_range(choice, 1, 8)

        if not v or opt is None:
            print(f"{RED}Invalid choice. Please enter a number between 1 and 8.{RESET}")
            continue

        if opt == 1:
            cli_take_quiz()
        elif opt == 2:
            cli_search_questions()
        elif opt == 3:
            cli_analytics_dashboard()
        elif opt == 4:
            cli_add_question()
        elif opt == 5:
            cli_export_reports()
        elif opt == 6:
            cli_bulk_import()
        elif opt == 7:
            confirm = input("Are you sure you want to reset data to seed defaults? (y/n): ").strip().lower()
            if confirm == 'y':
                reset_to_seeds()
                print(f"{GREEN}✓ Data re-seeded successfully.{RESET}")
        elif opt == 8:
            print(f"{CYAN}Thank you for using GreenFuture Quiz Application. Goodbye!🌱{RESET}")
            break

if __name__ == "__main__":
    main_cli()

import random
import re
from typing import List, Dict, Any, Optional, Tuple
from src.models import Question, QuizAttempt
from src.storage import load_questions, add_attempt

def get_available_topics() -> List[str]:
    """Returns a sorted list of unique topics available in the question bank."""
    questions = load_questions()
    topics = sorted(list({q.topic for q in questions}))
    return topics

def get_questions_by_topic(topic: str, count: Optional[int] = None) -> List[Question]:
    """Retrieves questions for a specific topic, optionally shuffled and limited in count."""
    questions = load_questions()
    filtered = [q for q in questions if q.topic.lower() == topic.lower()]
    random.shuffle(filtered)
    if count and count > 0:
        return filtered[:count]
    return filtered

def search_questions(keyword: str = "", topic: str = "", category: str = "", difficulty: str = "") -> List[Question]:
    """Searches questions by keyword, topic, category, and difficulty."""
    questions = load_questions()
    results = []
    
    keyword_clean = keyword.strip().lower()
    topic_clean = topic.strip().lower()
    category_clean = category.strip().lower()
    diff_clean = difficulty.strip().lower()

    for q in questions:
        match_kw = not keyword_clean or (keyword_clean in q.question_text.lower() or any(keyword_clean in opt.lower() for opt in q.options))
        match_topic = not topic_clean or (topic_clean == "all" or topic_clean in q.topic.lower())
        match_cat = not category_clean or (category_clean == "all" or category_clean in q.category.lower())
        match_diff = not diff_clean or (diff_clean == "all" or diff_clean == q.difficulty.lower())

        if match_kw and match_topic and match_cat and match_diff:
            results.append(q)

    return results

def evaluate_quiz_session(learner_name: str, topic: str, user_answers: List[Tuple[Question, int]]) -> QuizAttempt:
    """Evaluates user responses, computes score/percentage, creates and stores attempt."""
    score = 0
    total = len(user_answers)
    answers_details = []

    import datetime
    attempt_id = f"ATT-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}-{random.randint(100, 999)}"

    for q, selected_idx in user_answers:
        is_correct = (selected_idx == q.correct_option_index)
        if is_correct:
            score += 1
        
        answers_details.append({
            "question_id": q.id,
            "question_text": q.question_text,
            "selected_option": q.options[selected_idx] if 0 <= selected_idx < len(q.options) else "Invalid",
            "correct_option": q.options[q.correct_option_index],
            "is_correct": is_correct,
            "explanation": q.explanation
        })

    percentage = round((score / total * 100.0), 2) if total > 0 else 0.0

    attempt = QuizAttempt(
        attempt_id=attempt_id,
        learner_name=learner_name.strip() or "Anonymous Learner",
        topic=topic,
        score=score,
        total_questions=total,
        percentage=percentage,
        answers_details=answers_details
    )

    add_attempt(attempt)
    return attempt

# --- Defensive Input Validation Wrappers ---

def sanitize_string_input(raw_input: str, default_val: str = "") -> str:
    """Sanitizes user string input removing dangerous control characters."""
    if not raw_input:
        return default_val
    clean = raw_input.strip()
    clean = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', clean)
    return clean if clean else default_val

def validate_integer_range(value_str: str, min_val: int, max_val: int) -> Tuple[bool, Optional[int], str]:
    """Validates if input string is an integer within [min_val, max_val]."""
    if not value_str or not value_str.strip():
        return False, None, "Input cannot be empty."
    try:
        val = int(value_str.strip())
        if val < min_val or val > max_val:
            return False, None, f"Value must be between {min_val} and {max_val}."
        return True, val, "Valid"
    except ValueError:
        return False, None, "Please enter a valid numeric integer."

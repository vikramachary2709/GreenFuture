import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from typing import List, Dict, Any, Tuple, Optional
from pathlib import Path
from collections import defaultdict
from src.models import QuizAttempt, ExecutiveSummary
from src.storage import load_attempts
from config import MASTERY_THRESHOLD, EXPORTS_DIR

def calculate_executive_summary() -> ExecutiveSummary:
    """Computes aggregate metrics, topic breakdowns, and threshold warning indicators."""
    attempts = load_attempts()
    if not attempts:
        return ExecutiveSummary(
            total_attempts=0,
            total_learners=0,
            overall_average_score=0.0,
            pass_rate=0.0,
            topic_performance={},
            warning_topics=[]
        )

    total_attempts = len(attempts)
    unique_learners = len({a.learner_name.lower().strip() for a in attempts})
    
    total_pct_sum = sum(a.percentage for a in attempts)
    overall_avg_score = round(total_pct_sum / total_attempts, 2)

    passed_attempts = sum(1 for a in attempts if a.percentage >= (MASTERY_THRESHOLD * 100))
    pass_rate = round((passed_attempts / total_attempts) * 100, 2)

    # Topic-wise performance
    topic_data = defaultdict(list)
    for a in attempts:
        topic_data[a.topic].append(a)

    topic_perf = {}
    warning_topics = []

    for topic, t_attempts in topic_data.items():
        count = len(t_attempts)
        avg_pct = round(sum(a.percentage for a in t_attempts) / count, 2)
        t_passed = sum(1 for a in t_attempts if a.percentage >= (MASTERY_THRESHOLD * 100))
        t_pass_rate = round((t_passed / count) * 100, 2)

        topic_perf[topic] = {
            "attempts": count,
            "average_score": avg_pct,
            "pass_rate": t_pass_rate,
            "needs_review": avg_pct < (MASTERY_THRESHOLD * 100)
        }

        if avg_pct < (MASTERY_THRESHOLD * 100):
            warning_topics.append(topic)

    return ExecutiveSummary(
        total_attempts=total_attempts,
        total_learners=unique_learners,
        overall_average_score=overall_avg_score,
        pass_rate=pass_rate,
        topic_performance=topic_perf,
        warning_topics=warning_topics
    )

def generate_analytics_charts(save_to_disk: bool = True) -> Tuple[plt.Figure, plt.Figure]:
    """Generates Matplotlib performance bar chart and trend line chart."""
    summary = calculate_executive_summary()
    attempts = load_attempts()

    # Apply clean styling
    plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')

    # Chart 1: Topic Performance Comparison
    fig1, ax1 = plt.subplots(figsize=(8, 4.5))
    if summary.topic_performance:
        topics = list(summary.topic_performance.keys())
        avg_scores = [summary.topic_performance[t]["average_score"] for t in topics]
        colors = ['#2e7d32' if score >= 60 else '#c62828' for score in avg_scores]

        bars = ax1.bar(topics, avg_scores, color=colors, width=0.5, edgecolor='black', alpha=0.85)
        ax1.axhline(60, color='#d32f2f', linestyle='--', linewidth=1.5, label='Mastery Threshold (60%)')
        ax1.set_ylabel('Average Accuracy (%)', fontsize=11, fontweight='bold')
        ax1.set_title('Average Learner Performance by Topic', fontsize=13, fontweight='bold', pad=12)
        ax1.set_ylim(0, 105)
        ax1.legend(loc='upper right')

        # Annotate bars
        for bar in bars:
            height = bar.get_height()
            ax1.annotate(f'{height:.1f}%',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom', fontweight='bold')
        plt.xticks(rotation=15, ha='right')
    else:
        ax1.text(0.5, 0.5, 'No Attempt Data Available', ha='center', va='center', fontsize=14)

    plt.tight_layout()

    # Chart 2: Historical Score Trend
    fig2, ax2 = plt.subplots(figsize=(8, 4.5))
    if attempts:
        # Sort attempts by timestamp
        sorted_attempts = sorted(attempts, key=lambda x: x.timestamp)
        timestamps = [f"#{i+1}" for i in range(len(sorted_attempts))]
        scores = [a.percentage for a in sorted_attempts]

        ax2.plot(timestamps, scores, marker='o', color='#1976d2', linewidth=2, markersize=6, label='Attempt Score (%)')
        ax2.axhline(60, color='#d32f2f', linestyle='--', linewidth=1.5, label='Pass Threshold (60%)')
        ax2.set_xlabel('Attempt History Sequence', fontsize=11, fontweight='bold')
        ax2.set_ylabel('Score Percentage (%)', fontsize=11, fontweight='bold')
        ax2.set_title('Historical Quiz Performance Trend', fontsize=13, fontweight='bold', pad=12)
        ax2.set_ylim(0, 105)
        ax2.legend(loc='lower right')
    else:
        ax2.text(0.5, 0.5, 'No Attempt Data Available', ha='center', va='center', fontsize=14)

    plt.tight_layout()

    if save_to_disk:
        fig1.savefig(EXPORTS_DIR / "topic_performance.png", dpi=200, bbox_inches='tight')
        fig2.savefig(EXPORTS_DIR / "score_trend.png", dpi=200, bbox_inches='tight')

    return fig1, fig2

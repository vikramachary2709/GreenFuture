import json
import csv
import logging
from pathlib import Path
from typing import List, Dict, Any, Tuple
import sys

# Ensure parent directory is in sys.path when running standalone
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import QUESTIONS_JSON, QUESTIONS_CSV, ATTEMPTS_JSON, ATTEMPTS_CSV
from src.models import Question, QuizAttempt

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

SEED_QUESTIONS = [
    # Python Programming (10 questions)
    {
        "id": "PY001",
        "topic": "Python Programming",
        "category": "Basics",
        "question_text": "Which of the following data types in Python is immutable?",
        "options": ["List", "Dictionary", "Tuple", "Set"],
        "correct_option_index": 2,
        "explanation": "Tuples are immutable sequences in Python; their elements cannot be modified after creation.",
        "difficulty": "Easy"
    },
    {
        "id": "PY002",
        "topic": "Python Programming",
        "category": "Functions",
        "question_text": "What keyword is used to create an anonymous function in Python?",
        "options": ["def", "lambda", "func", "anonymous"],
        "correct_option_index": 1,
        "explanation": "The 'lambda' keyword is used to create inline, single-expression anonymous functions.",
        "difficulty": "Easy"
    },
    {
        "id": "PY003",
        "topic": "Python Programming",
        "category": "Data Structures",
        "question_text": "What is the time complexity of looking up a key in a Python dictionary on average?",
        "options": ["O(1)", "O(n)", "O(log n)", "O(n^2)"],
        "correct_option_index": 0,
        "explanation": "Python dictionaries use hash tables, providing average O(1) key lookup time.",
        "difficulty": "Medium"
    },
    {
        "id": "PY004",
        "topic": "Python Programming",
        "category": "OOP",
        "question_text": "Which method is automatically called when a new class instance is created in Python?",
        "options": ["__new__", "__init__", "__construct__", "__start__"],
        "correct_option_index": 1,
        "explanation": "'__init__' serves as the initializer method for newly instantiated Python objects.",
        "difficulty": "Easy"
    },
    {
        "id": "PY005",
        "topic": "Python Programming",
        "category": "Exception Handling",
        "question_text": "Which block in Python always executes regardless of whether an exception occurred?",
        "options": ["try", "except", "finally", "else"],
        "correct_option_index": 2,
        "explanation": "The 'finally' block executes cleanup operations regardless of exception status.",
        "difficulty": "Medium"
    },
    {
        "id": "PY006",
        "topic": "Python Programming",
        "category": "Modules",
        "question_text": "Which built-in Python module provides functions for interacting with the operating system?",
        "options": ["sys", "os", "platform", "subprocess"],
        "correct_option_index": 1,
        "explanation": "The 'os' module provides access to operating system dependent functionality like file paths and environment variables.",
        "difficulty": "Easy"
    },
    {
        "id": "PY007",
        "topic": "Python Programming",
        "category": "Advanced",
        "question_text": "What decorator is used to convert a class method into a read-only property?",
        "options": ["@classmethod", "@staticmethod", "@property", "@getter"],
        "correct_option_index": 2,
        "explanation": "The '@property' decorator allows class methods to be accessed like attributes.",
        "difficulty": "Medium"
    },
    {
        "id": "PY008",
        "topic": "Python Programming",
        "category": "Data Structures",
        "question_text": "Which method removes and returns the last item from a Python list?",
        "options": ["remove()", "pop()", "delete()", "extract()"],
        "correct_option_index": 1,
        "explanation": "The 'pop()' method removes and returns the element at the specified position (default last).",
        "difficulty": "Easy"
    },
    {
        "id": "PY009",
        "topic": "Python Programming",
        "category": "Iterators",
        "question_text": "What function converts an iterable into an enumerated object returning index-value pairs?",
        "options": ["zip()", "enumerate()", "map()", "filter()"],
        "correct_option_index": 1,
        "explanation": "'enumerate()' adds a counter to an iterable and returns it as an enumerate object.",
        "difficulty": "Medium"
    },
    {
        "id": "PY010",
        "topic": "Python Programming",
        "category": "File I/O",
        "question_text": "What is the recommended statement to open files safely ensuring automatic closure?",
        "options": ["open()", "with open() as", "try-open", "file.open()"],
        "correct_option_index": 1,
        "explanation": "The 'with' context manager ensures files are properly closed even if exceptions occur.",
        "difficulty": "Easy"
    },

    # Renewable Energy (8 questions)
    {
        "id": "RE001",
        "topic": "Renewable Energy",
        "category": "Solar",
        "question_text": "What device converts sunlight directly into electricity using the photovoltaic effect?",
        "options": ["Solar thermal collector", "Photovoltaic (PV) cell", "Inverter", "Charge controller"],
        "correct_option_index": 1,
        "explanation": "Photovoltaic cells directly convert photon energy from sunlight into electrical energy.",
        "difficulty": "Easy"
    },
    {
        "id": "RE002",
        "topic": "Renewable Energy",
        "category": "Wind",
        "question_text": "What component in a wind turbine converts mechanical rotational energy into electrical energy?",
        "options": ["Rotor blade", "Gearbox", "Generator", "Nacelle"],
        "correct_option_index": 2,
        "explanation": "The electrical generator converts the mechanical energy of the rotating shaft into electricity.",
        "difficulty": "Easy"
    },
    {
        "id": "RE003",
        "topic": "Renewable Energy",
        "category": "Hydroelectric",
        "question_text": "Which energy storage concept pumps water uphill during low demand and releases it through turbines during peak demand?",
        "options": ["Run-of-river", "Pumped-storage hydropower", "Tidal barrage", "Wave energy converter"],
        "correct_option_index": 1,
        "explanation": "Pumped-storage hydropower acts as a large-scale gravitational battery storing potential energy.",
        "difficulty": "Medium"
    },
    {
        "id": "RE004",
        "topic": "Renewable Energy",
        "category": "Geothermal",
        "question_text": "What source of heat powers geothermal energy production?",
        "options": ["Solar radiation", "Earth's internal thermal energy", "Atmospheric pressure", "Ocean currents"],
        "correct_option_index": 1,
        "explanation": "Geothermal systems harness heat generated from radioactive decay and primordial heat within the Earth.",
        "difficulty": "Easy"
    },
    {
        "id": "RE005",
        "topic": "Renewable Energy",
        "category": "Storage",
        "question_text": "Which battery technology currently dominates utility-scale renewable energy storage?",
        "options": ["Lead-acid", "Lithium-ion", "Nickel-cadmium", "Sodium-sulfur"],
        "correct_option_index": 1,
        "explanation": "Lithium-ion batteries are widely deployed due to high energy density and falling manufacturing costs.",
        "difficulty": "Medium"
    },
    {
        "id": "RE006",
        "topic": "Renewable Energy",
        "category": "Hydrogen",
        "question_text": "What color designation is given to hydrogen produced via water electrolysis powered by renewable electricity?",
        "options": ["Grey Hydrogen", "Blue Hydrogen", "Green Hydrogen", "Brown Hydrogen"],
        "correct_option_index": 2,
        "explanation": "Green hydrogen is produced using renewable energy sources without emitting greenhouse gases.",
        "difficulty": "Medium"
    },
    {
        "id": "RE007",
        "topic": "Renewable Energy",
        "category": "Grid Integration",
        "question_text": "What term refers to a small-scale electricity network that can operate independently from the main grid?",
        "options": ["Smart Grid", "Microgrid", "Supergrid", "Off-grid node"],
        "correct_option_index": 1,
        "explanation": "Microgrids are localized power systems that can disconnect from the main grid during outages.",
        "difficulty": "Medium"
    },
    {
        "id": "RE008",
        "topic": "Renewable Energy",
        "category": "Bioenergy",
        "question_text": "What primary gas is captured from anaerobic digestion of organic waste to produce biogas?",
        "options": ["Carbon dioxide", "Methane", "Nitrous oxide", "Ethane"],
        "correct_option_index": 1,
        "explanation": "Biogas produced by anaerobic digestion consists mostly of methane (CH4) and carbon dioxide.",
        "difficulty": "Medium"
    },

    # Environmental Science (8 questions)
    {
        "id": "ENV001",
        "topic": "Environmental Science",
        "category": "Climate",
        "question_text": "Which greenhouse gas has the highest warming potential per molecule over a 100-year timescale among common gases?",
        "options": ["Carbon dioxide", "Methane", "Nitrous oxide", "Water vapor"],
        "correct_option_index": 2,
        "explanation": "Nitrous oxide (N2O) has a global warming potential nearly 300 times greater than CO2.",
        "difficulty": "Medium"
    },
    {
        "id": "ENV002",
        "topic": "Environmental Science",
        "category": "Oceans",
        "question_text": "What process occurs when seawater absorbs excess atmospheric carbon dioxide, lowering oceanic pH?",
        "options": ["Eutrophication", "Ocean acidification", "Thermal expansion", "Salinization"],
        "correct_option_index": 1,
        "explanation": "Absorbed CO2 forms carbonic acid in seawater, decreasing ocean pH and harming marine calcifiers.",
        "difficulty": "Easy"
    },
    {
        "id": "ENV003",
        "topic": "Environmental Science",
        "category": "Ecology",
        "question_text": "What term describes the maximum population size of a species that an ecosystem can sustain indefinitely?",
        "options": ["Biotic potential", "Carrying capacity", "Ecological footprint", "Trophic limit"],
        "correct_option_index": 1,
        "explanation": "Carrying capacity is the environmental threshold for population size limited by resources.",
        "difficulty": "Easy"
    },
    {
        "id": "ENV004",
        "topic": "Environmental Science",
        "category": "Pollution",
        "question_text": "What atmospheric phenomenon traps pollutants near the ground when warm air overlays cooler air?",
        "options": ["Greenhouse effect", "Temperature inversion", "Coriolis effect", "Urban heat island"],
        "correct_option_index": 1,
        "explanation": "Temperature inversions prevent vertical air mixing, trapping smog and particulate matter.",
        "difficulty": "Hard"
    },
    {
        "id": "ENV005",
        "topic": "Environmental Science",
        "category": "Biodiversity",
        "question_text": "Which international treaty aims to protect biodiversity by regulating international wildlife trade?",
        "options": ["Kyoto Protocol", "Paris Agreement", "CITES", "Montreal Protocol"],
        "correct_option_index": 2,
        "explanation": "CITES (Convention on International Trade in Endangered Species) regulates wild fauna and flora trade.",
        "difficulty": "Medium"
    },
    {
        "id": "ENV006",
        "topic": "Environmental Science",
        "category": "Soil",
        "question_text": "What ecological process converts atmospheric nitrogen gas (N2) into plant-usable ammonia or nitrates?",
        "options": ["Nitrification", "Nitrogen fixation", "Denitrification", "Assimilation"],
        "correct_option_index": 1,
        "explanation": "Nitrogen fixation is carried out by specialized bacteria (e.g. Rhizobium) and lightning.",
        "difficulty": "Medium"
    },
    {
        "id": "ENV007",
        "topic": "Environmental Science",
        "category": "Forestry",
        "question_text": "What process describes the gradual restoration and regrowth of a forest on cleared or degraded land?",
        "options": ["Afforestation", "Reforestation", "Deforestation", "Desertification"],
        "correct_option_index": 1,
        "explanation": "Reforestation is the re-establishment of forest cover on historically forested lands.",
        "difficulty": "Easy"
    },
    {
        "id": "ENV008",
        "topic": "Environmental Science",
        "category": "Water Resources",
        "question_text": "What term describes the excessive enrichment of water bodies with nutrients leading to algal blooms?",
        "options": ["Acidification", "Eutrophication", "Bioaccumulation", "Thermal pollution"],
        "correct_option_index": 1,
        "explanation": "Eutrophication caused by agricultural runoff creates hypoxia and 'dead zones' in aquatic ecosystems.",
        "difficulty": "Easy"
    },

    # Sustainable Technology (6 questions)
    {
        "id": "ST001",
        "topic": "Sustainable Technology",
        "category": "Circular Economy",
        "question_text": "What core economic framework aims to eliminate waste and keep materials in continual use?",
        "options": ["Linear economy", "Circular economy", "Command economy", "Free market economy"],
        "correct_option_index": 1,
        "explanation": "The circular economy minimizes resource inputs and waste generation through reuse and recycling.",
        "difficulty": "Easy"
    },
    {
        "id": "ST002",
        "topic": "Sustainable Technology",
        "category": "Smart Cities",
        "question_text": "What technology allows municipal energy grids to dynamically monitor and adjust supply using real-time data?",
        "options": ["Legacy grid", "Smart grid", "Analog meter", "Static substation"],
        "correct_option_index": 1,
        "explanation": "Smart grids use IoT sensors and automated dispatch to optimize power distribution.",
        "difficulty": "Easy"
    },
    {
        "id": "ST003",
        "topic": "Sustainable Technology",
        "category": "Mobility",
        "question_text": "What key metric determines the total energy efficiency of electric vehicles from grid generation to wheels?",
        "options": ["Well-to-wheel efficiency", "Fuel economy index", "Combustion ratio", "Brake horsepower"],
        "correct_option_index": 0,
        "explanation": "Well-to-wheel efficiency accounts for all losses from power station generation down to vehicle propulsion.",
        "difficulty": "Hard"
    },
    {
        "id": "ST004",
        "topic": "Sustainable Technology",
        "category": "Green Computing",
        "question_text": "What metric measures the energy efficiency of data centers by comparing total power to IT equipment power?",
        "options": ["PUE (Power Usage Effectiveness)", "PUE (Public Utility Metric)", "EER (Energy Efficiency Ratio)", "COP (Coefficient of Performance)"],
        "correct_option_index": 0,
        "explanation": "PUE = Total Facility Energy / IT Equipment Energy; a score closer to 1.0 represents ideal efficiency.",
        "difficulty": "Medium"
    },
    {
        "id": "ST005",
        "topic": "Sustainable Technology",
        "category": "Buildings",
        "question_text": "What architectural rating system certifies green building design, construction, and operation globally?",
        "options": ["ISO 9001", "LEED", "CE mark", "Energy Star"],
        "correct_option_index": 1,
        "explanation": "LEED (Leadership in Energy and Environmental Design) is a leading global green building certification.",
        "difficulty": "Easy"
    },
    {
        "id": "ST006",
        "topic": "Sustainable Technology",
        "category": "Materials",
        "question_text": "Which plant-derived bio-plastic material is commonly used in 3D printing as a sustainable alternative to petroleum plastics?",
        "options": ["ABS", "PLA (Polylactic Acid)", "PETG", "Polycarbonate"],
        "correct_option_index": 1,
        "explanation": "PLA is a biodegradable thermoplastic derived from renewable plant starch like corn or sugarcane.",
        "difficulty": "Easy"
    }
]

SEED_ATTEMPTS = [
    {
        "attempt_id": "ATT001",
        "learner_name": "Alice Johnson",
        "topic": "Python Programming",
        "score": 5,
        "total_questions": 5,
        "percentage": 100.0,
        "timestamp": "2026-11-18 10:15:00",
        "answers_details": []
    },
    {
        "attempt_id": "ATT002",
        "learner_name": "Bob Smith",
        "topic": "Python Programming",
        "score": 3,
        "total_questions": 5,
        "percentage": 60.0,
        "timestamp": "2026-11-18 11:30:00",
        "answers_details": []
    },
    {
        "attempt_id": "ATT003",
        "learner_name": "Charlie Davis",
        "topic": "Renewable Energy",
        "score": 4,
        "total_questions": 5,
        "percentage": 80.0,
        "timestamp": "2026-11-19 09:00:00",
        "answers_details": []
    },
    {
        "attempt_id": "ATT004",
        "learner_name": "Dana Lee",
        "topic": "Environmental Science",
        "score": 2,
        "total_questions": 5,
        "percentage": 40.0,
        "timestamp": "2026-11-19 14:20:00",
        "answers_details": []
    },
    {
        "attempt_id": "ATT005",
        "learner_name": "Evan Wright",
        "topic": "Sustainable Technology",
        "score": 5,
        "total_questions": 5,
        "percentage": 100.0,
        "timestamp": "2026-11-19 16:45:00",
        "answers_details": []
    }
]

def initialize_storage() -> None:
    """Ensures data files exist and are valid. Auto-recovers if missing or corrupted."""
    _load_or_initialize_questions()
    _load_or_initialize_attempts()

def _load_or_initialize_questions() -> List[Question]:
    """Loads questions from JSON, recovering gracefully if corrupted or missing."""
    questions = []
    need_seed = False

    if not QUESTIONS_JSON.exists():
        logging.info("Questions file missing. Creating new dataset with seed records...")
        need_seed = True
    else:
        try:
            with open(QUESTIONS_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
                if not isinstance(data, list):
                    raise ValueError("JSON content is not a list")
                questions = [Question.from_dict(q) for q in data]
        except (json.JSONDecodeError, ValueError, FileNotFoundError) as e:
            logging.warning(f"Questions data corrupted or invalid ({e}). Auto-repairing with clean templates...")
            need_seed = True

    if need_seed or not questions:
        questions = [Question.from_dict(q) for q in SEED_QUESTIONS]
        save_questions(questions)

    # Sync to CSV as secondary format
    sync_questions_to_csv(questions)
    return questions

def save_questions(questions: List[Question]) -> bool:
    """Saves list of Question objects to JSON and CSV files safely."""
    try:
        data = [q.to_dict() for q in questions]
        with open(QUESTIONS_JSON, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        sync_questions_to_csv(questions)
        return True
    except Exception as e:
        logging.error(f"Failed to save questions: {e}")
        return False

def sync_questions_to_csv(questions: List[Question]) -> None:
    """Exports questions to CSV format for external review or audit."""
    try:
        fieldnames = ["id", "topic", "category", "question_text", "options", "correct_option_index", "explanation", "difficulty"]
        with open(QUESTIONS_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for q in questions:
                d = q.to_dict()
                d["options"] = " | ".join(d["options"])  # pipe separated in CSV
                writer.writerow(d)
    except Exception as e:
        logging.error(f"Failed to write questions CSV: {e}")

def load_questions() -> List[Question]:
    """Retrieves all questions from local storage."""
    return _load_or_initialize_questions()

def _load_or_initialize_attempts() -> List[QuizAttempt]:
    """Loads quiz attempts from JSON, auto-recovering if corrupted or missing."""
    attempts = []
    need_seed = False

    if not ATTEMPTS_JSON.exists():
        logging.info("Attempts file missing. Creating new dataset with seed records...")
        need_seed = True
    else:
        try:
            with open(ATTEMPTS_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
                if not isinstance(data, list):
                    raise ValueError("JSON content is not a list")
                attempts = [QuizAttempt.from_dict(a) for a in data]
        except (json.JSONDecodeError, ValueError, FileNotFoundError) as e:
            logging.warning(f"Attempts data corrupted or invalid ({e}). Auto-repairing with clean template...")
            need_seed = True

    if need_seed or not attempts:
        attempts = [QuizAttempt.from_dict(a) for a in SEED_ATTEMPTS]
        save_attempts(attempts)

    sync_attempts_to_csv(attempts)
    return attempts

def save_attempts(attempts: List[QuizAttempt]) -> bool:
    """Saves quiz attempts to JSON and CSV."""
    try:
        data = [a.to_dict() for a in attempts]
        with open(ATTEMPTS_JSON, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        sync_attempts_to_csv(attempts)
        return True
    except Exception as e:
        logging.error(f"Failed to save attempts: {e}")
        return False

def sync_attempts_to_csv(attempts: List[QuizAttempt]) -> None:
    """Exports attempts to CSV format."""
    try:
        fieldnames = ["attempt_id", "learner_name", "topic", "score", "total_questions", "percentage", "timestamp"]
        with open(ATTEMPTS_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for a in attempts:
                d = a.to_dict()
                d.pop("answers_details", None)
                writer.writerow(d)
    except Exception as e:
        logging.error(f"Failed to write attempts CSV: {e}")

def load_attempts() -> List[QuizAttempt]:
    """Retrieves all attempt records."""
    return _load_or_initialize_attempts()

def add_attempt(attempt: QuizAttempt) -> bool:
    """Appends a new attempt record and saves."""
    attempts = load_attempts()
    attempts.append(attempt)
    return save_attempts(attempts)

def add_question(question: Question) -> bool:
    """Appends a new question record and saves."""
    questions = load_questions()
    questions.append(question)
    return save_questions(questions)

def reset_to_seeds() -> None:
    """Resets data files to seed datasets."""
    questions = [Question.from_dict(q) for q in SEED_QUESTIONS]
    attempts = [QuizAttempt.from_dict(a) for a in SEED_ATTEMPTS]
    save_questions(questions)
    save_attempts(attempts)

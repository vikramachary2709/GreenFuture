import os
from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
EXPORTS_DIR = BASE_DIR / "exports"

# File paths
QUESTIONS_JSON = DATA_DIR / "questions.json"
QUESTIONS_CSV = DATA_DIR / "questions.csv"
ATTEMPTS_JSON = DATA_DIR / "attempts.json"
ATTEMPTS_CSV = DATA_DIR / "attempts.csv"

# Configuration constants
MASTERY_THRESHOLD = 0.60  # 60% threshold for warning flag
DEFAULT_QUIZ_LENGTH = 5

# Create necessary directories
DATA_DIR.mkdir(parents=True, exist_ok=True)
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

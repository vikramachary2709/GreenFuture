import streamlit as st
import pandas as pd
import time
from pathlib import Path
import sys

# Add root directory to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.storage import initialize_storage, load_questions, load_attempts, reset_to_seeds, add_question
from src.quiz_engine import (
    get_available_topics,
    get_questions_by_topic,
    search_questions,
    evaluate_quiz_session
)
from src.analytics import calculate_executive_summary, generate_analytics_charts
from src.export_import import (
    export_executive_summary_markdown,
    export_audit_log_text,
    bulk_import_questions_csv
)
from src.models import Question, QuizAttempt

# Page configuration
st.set_page_config(
    page_title="GreenFuture Quiz Application",
    page_icon="🌱",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        color: #1e4620;
        font-weight: 800;
        margin-bottom: 0px;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #4b6b4c;
        margin-bottom: 20px;
    }
    .metric-card {
        background-color: #f4f9f4;
        border-radius: 10px;
        padding: 18px;
        border-left: 5px solid #2e7d32;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .warning-card {
        background-color: #fff8e1;
        border-radius: 8px;
        padding: 12px;
        border-left: 5px solid #ffa000;
        margin-bottom: 12px;
    }
    .badge-pass {
        background-color: #e8f5e9;
        color: #2e7d32;
        padding: 4px 10px;
        border-radius: 12px;
        font-weight: bold;
    }
    .badge-fail {
        background-color: #ffebee;
        color: #c62828;
        padding: 4px 10px;
        border-radius: 12px;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# Ensure storage initialized
initialize_storage()

# Session State initialization for quiz session
if "quiz_active" not in st.session_state:
    st.session_state.quiz_active = False
if "quiz_questions" not in st.session_state:
    st.session_state.quiz_questions = []
if "quiz_current_idx" not in st.session_state:
    st.session_state.quiz_current_idx = 0
if "quiz_user_answers" not in st.session_state:
    st.session_state.quiz_user_answers = []
if "quiz_submitted" not in st.session_state:
    st.session_state.quiz_submitted = False
if "quiz_learner_name" not in st.session_state:
    st.session_state.quiz_learner_name = ""
if "quiz_topic" not in st.session_state:
    st.session_state.quiz_topic = ""

# App Header
st.markdown("<p class='main-header'>🌱 GreenFuture Python Quiz Application</p>", unsafe_allow_html=True)
st.markdown("<p class='sub-header'>Automated Topic-Wise Quizzes, Real-Time Scoring & Executive Analytics</p>", unsafe_allow_html=True)

# Sidebar Navigation
st.sidebar.title("Navigation Menu")
page = st.sidebar.radio(
    "Select Functionality:",
    ["🎯 Take Quiz", "📊 Analytics & Trends", "🔍 Search & Manage Quizzes", "📥 Bulk Import & Export"]
)

st.sidebar.markdown("---")
st.sidebar.subheader("System Actions")
if st.sidebar.button("🔄 Reset to Seed Data"):
    reset_to_seeds()
    st.sidebar.success("Database re-seeded successfully!")
    st.rerun()

st.sidebar.markdown("""
<div style='font-size: 0.85rem; color: #666; margin-top: 20px;'>
<b>GreenFuture Hackathon Project</b><br>
Domain: Education & Sustainability<br>
Built with Python & Streamlit
</div>
""", unsafe_allow_html=True)

# ==========================================
# PAGE 1: TAKE QUIZ
# ==========================================
if page == "🎯 Take Quiz":
    st.header("🎯 Interactive Topic-Wise Quiz Engine")

    topics = get_available_topics()
    if not topics:
        st.error("No topics found in dataset.")
        st.stop()

    if not st.session_state.quiz_active and not st.session_state.quiz_submitted:
        col1, col2 = st.columns([1, 1])
        with col1:
            learner_name = st.text_input("Learner Name / ID:", value="Alice Johnson", help="Enter student or learner name.")
            selected_topic = st.selectbox("Select Topic:", topics)
        
        with col2:
            topic_qs = get_questions_by_topic(selected_topic)
            max_q = len(topic_qs)
            num_q = st.slider("Number of Questions:", min_value=1, max_value=max(max_q, 1), value=min(5, max_q))
            
            st.info(f"💡 Topic '{selected_topic}' has {max_q} total questions available.")

        if st.button("🚀 Start Quiz Session", type="primary", use_container_width=True):
            st.session_state.quiz_questions = topic_qs[:num_q]
            st.session_state.quiz_current_idx = 0
            st.session_state.quiz_user_answers = []
            st.session_state.quiz_active = True
            st.session_state.quiz_submitted = False
            st.session_state.quiz_learner_name = learner_name
            st.session_state.quiz_topic = selected_topic
            st.rerun()

    elif st.session_state.quiz_active and not st.session_state.quiz_submitted:
        q_list = st.session_state.quiz_questions
        curr_idx = st.session_state.quiz_current_idx
        total_q = len(q_list)

        # Progress bar
        st.progress((curr_idx) / total_q)
        st.caption(f"Question {curr_idx + 1} of {total_q} | Learner: **{st.session_state.quiz_learner_name}** | Topic: **{st.session_state.quiz_topic}**")

        q = q_list[curr_idx]
        st.subheader(f"Q{curr_idx + 1}: {q.question_text}")
        st.caption(f"Category: `{q.category}` | Difficulty: `{q.difficulty}`")

        # Answer radio button
        selected_option = st.radio(
            "Choose your answer:",
            q.options,
            key=f"q_{q.id}_{curr_idx}"
        )

        col_nav1, col_nav2 = st.columns([1, 1])
        with col_nav2:
            button_label = "Next Question ➡️" if (curr_idx + 1 < total_q) else "Submit Quiz 🏁"
            if st.button(button_label, type="primary", use_container_width=True):
                selected_opt_idx = q.options.index(selected_option)
                st.session_state.quiz_user_answers.append((q, selected_opt_idx))

                if curr_idx + 1 < total_q:
                    st.session_state.quiz_current_idx += 1
                else:
                    st.session_state.quiz_active = False
                    st.session_state.quiz_submitted = True
                st.rerun()

    elif st.session_state.quiz_submitted:
        st.success("🎉 Quiz Submitted Successfully!")
        
        # Evaluate session
        attempt = evaluate_quiz_session(
            st.session_state.quiz_learner_name,
            st.session_state.quiz_topic,
            st.session_state.quiz_user_answers
        )

        # Metrics display
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Learner", attempt.learner_name)
        m2.metric("Topic", attempt.topic)
        m3.metric("Score", f"{attempt.score} / {attempt.total_questions}")
        m4.metric("Accuracy Percentage", f"{attempt.percentage}%")

        if attempt.percentage >= 60.0:
            st.balloons()
            st.success("🌟 **MASTERY ACHIEVED!** Learner met or exceeded the 60% proficiency threshold.")
        else:
            st.warning("⚠️ **NEEDS REVIEW!** Learner scored below the 60% proficiency threshold.")

        st.markdown("### 📋 Detailed Question Review")
        for idx, detail in enumerate(attempt.answers_details, 1):
            is_cor = detail["is_correct"]
            icon = "✅" if is_cor else "❌"
            color = "green" if is_cor else "red"
            
            with st.expander(f"{icon} Q{idx}: {detail['question_text']}"):
                st.write(f"**Your Answer:** {detail['selected_option']}")
                st.write(f"**Correct Answer:** {detail['correct_option']}")
                if detail["explanation"]:
                    st.info(f"**Explanation:** {detail['explanation']}")

        if st.button("🔄 Take Another Quiz", type="primary"):
            st.session_state.quiz_active = False
            st.session_state.quiz_submitted = False
            st.rerun()

# ==========================================
# PAGE 2: ANALYTICS & TRENDS
# ==========================================
elif page == "📊 Analytics & Trends":
    st.header("📊 Executive Summary & Performance Analytics")

    summary = calculate_executive_summary()

    # KPI Row
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Quiz Attempts", summary.total_attempts)
    col2.metric("Unique Learners", summary.total_learners)
    col3.metric("Overall Avg Score", f"{summary.overall_average_score}%")
    col4.metric("Overall Pass Rate (>=60%)", f"{summary.pass_rate}%")

    st.markdown("---")

    # Warning banner if any
    if summary.warning_topics:
        st.warning("### ⚠️ Threshold Warning Flags Active")
        st.write("The following topics have average learner scores falling below the **60% mastery threshold**:")
        for wt in summary.warning_topics:
            avg_s = summary.topic_performance[wt]["average_score"]
            st.markdown(f"- 🔴 **{wt}**: Average Accuracy `{avg_s}%`")
    else:
        st.success("✅ **System Alert:** All topics currently meet or exceed the 60% proficiency threshold!")

    st.markdown("---")

    # Visual Matplotlib Charts
    st.subheader("📈 Performance Trend & Distribution Charts")
    fig1, fig2 = generate_analytics_charts(save_to_disk=False)
    
    c1, c2 = st.columns(2)
    with c1:
        st.pyplot(fig1)
    with c2:
        st.pyplot(fig2)

    st.markdown("---")
    st.subheader("📋 Topic Breakdown Table")
    if summary.topic_performance:
        df_topic = pd.DataFrame.from_dict(summary.topic_performance, orient='index')
        df_topic.index.name = "Topic"
        df_topic = df_topic.reset_index()
        df_topic.columns = ["Topic", "Total Attempts", "Average Score (%)", "Pass Rate (%)", "Needs Review Flag"]
        st.dataframe(df_topic, use_container_width=True)

# ==========================================
# PAGE 3: SEARCH & MANAGE QUIZZES
# ==========================================
elif page == "🔍 Search & Manage Quizzes":
    st.header("🔍 Question Bank Management")

    st.subheader("Search & Query Filter")
    c1, c2, c3 = st.columns(3)
    with c1:
        search_kw = st.text_input("Keyword Search:", placeholder="e.g. Python, solar, energy")
    with c2:
        top_list = ["All"] + get_available_topics()
        sel_t = st.selectbox("Filter Topic:", top_list)
    with c3:
        sel_diff = st.selectbox("Filter Difficulty:", ["All", "Easy", "Medium", "Hard"])

    results = search_questions(
        keyword=search_kw,
        topic="" if sel_t == "All" else sel_t,
        difficulty="" if sel_diff == "All" else sel_diff
    )

    st.caption(f"Showing **{len(results)}** matching questions:")

    for q in results:
        with st.expander(f"[{q.id}] {q.question_text} ({q.topic} - {q.difficulty})"):
            st.write(f"**Category:** {q.category}")
            st.write("**Options:**")
            for idx, opt in enumerate(q.options):
                prefix = "✅ " if idx == q.correct_option_index else "⚪ "
                st.write(f"  {prefix}{opt}")
            if q.explanation:
                st.info(f"**Explanation:** {q.explanation}")

    st.markdown("---")
    st.subheader("➕ Add New Question")
    with st.form("add_question_form"):
        f_id = st.text_input("Question ID:", value=f"PY{int(time.time()) % 1000:03d}")
        f_topic = st.text_input("Topic:", value="Python Programming")
        f_cat = st.text_input("Category:", value="General")
        f_qtext = st.text_area("Question Text:")
        
        f_opt1 = st.text_input("Option 1:")
        f_opt2 = st.text_input("Option 2:")
        f_opt3 = st.text_input("Option 3:")
        f_opt4 = st.text_input("Option 4:")

        f_correct = st.selectbox("Correct Option Index:", [1, 2, 3, 4], index=0)
        f_exp = st.text_input("Explanation:")
        f_diff = st.selectbox("Difficulty:", ["Easy", "Medium", "Hard"], index=1)

        submitted = st.form_submit_button("Save Question")
        if submitted:
            if not f_qtext or not f_opt1 or not f_opt2:
                st.error("Please provide question text and at least 2 options.")
            else:
                opts = [o for o in [f_opt1, f_opt2, f_opt3, f_opt4] if o.strip()]
                new_q = Question(
                    id=f_id,
                    topic=f_topic,
                    category=f_cat,
                    question_text=f_qtext,
                    options=opts,
                    correct_option_index=min(f_correct - 1, len(opts) - 1),
                    explanation=f_exp,
                    difficulty=f_diff
                )
                if add_question(new_q):
                    st.success(f"Question '{f_id}' added successfully!")
                    time.sleep(1)
                    st.rerun()

# ==========================================
# PAGE 4: BULK IMPORT & EXPORT
# ==========================================
elif page == "📥 Bulk Import & Export":
    st.header("📥 Bulk Dataset Import & Export Engine")

    col_imp, col_exp = st.columns(2)

    with col_imp:
        st.subheader("📂 Bulk CSV Question Import")
        uploaded_file = st.file_uploader("Upload CSV Question Dataset:", type=["csv"])
        if uploaded_file is not None:
            content = uploaded_file.getvalue().decode("utf-8")
            if st.button("Process Bulk Import", type="primary"):
                imported, total, errors = bulk_import_questions_csv(content)
                st.success(f"Successfully imported **{imported}/{total}** questions!")
                if errors:
                    st.warning("Validation Logs & Errors:")
                    for e in errors:
                        st.write(f"- {e}")

    with col_exp:
        st.subheader("📤 Export Reports & Audit Logs")
        
        md_file = export_executive_summary_markdown()
        with open(md_file, "r", encoding="utf-8") as f:
            md_data = f.read()
        
        st.download_button(
            label="📄 Download Executive Summary (.md)",
            data=md_data,
            file_name=md_file.name,
            mime="text/markdown",
            use_container_width=True
        )

        txt_file = export_audit_log_text()
        with open(txt_file, "r", encoding="utf-8") as f:
            txt_data = f.read()

        st.download_button(
            label="📜 Download System Audit Log (.txt)",
            data=txt_data,
            file_name=txt_file.name,
            mime="text/plain",
            use_container_width=True
        )

        # CSV Attempts download
        attempts = load_attempts()
        df_att = pd.DataFrame([a.to_dict() for a in attempts])
        if not df_att.empty:
            df_att.drop(columns=["answers_details"], errors="ignore", inplace=True)
            csv_bytes = df_att.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="📊 Download Attempts Dataset (.csv)",
                data=csv_bytes,
                file_name="attempts_dataset.csv",
                mime="text/csv",
                use_container_width=True
            )

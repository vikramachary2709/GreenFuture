import unittest
import os
import sys
from pathlib import Path

# Add root directory to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models import Question, QuizAttempt
from src.storage import initialize_storage, load_questions, load_attempts, reset_to_seeds
from src.quiz_engine import (
    get_available_topics,
    get_questions_by_topic,
    search_questions,
    evaluate_quiz_session,
    validate_integer_range
)
from src.analytics import calculate_executive_summary
from src.export_import import bulk_import_questions_csv

class TestGreenFutureQuizApp(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        initialize_storage()

    def test_01_seed_questions_loading(self):
        questions = load_questions()
        self.assertGreaterEqual(len(questions), 30, "Seed dataset should contain at least 30 questions.")

    def test_02_available_topics(self):
        topics = get_available_topics()
        self.assertIn("Python Programming", topics)
        self.assertIn("Renewable Energy", topics)
        self.assertIn("Environmental Science", topics)

    def test_03_topic_filtering(self):
        py_questions = get_questions_by_topic("Python Programming", count=5)
        self.assertEqual(len(py_questions), 5)
        for q in py_questions:
            self.assertEqual(q.topic, "Python Programming")

    def test_04_defensive_input_validation(self):
        valid, val, err = validate_integer_range("3", 1, 5)
        self.assertTrue(valid)
        self.assertEqual(val, 3)

        invalid, val_inv, err_inv = validate_integer_range("abc", 1, 5)
        self.assertFalse(invalid)
        self.assertIn("numeric", err_inv)

        out_of_range, _, err_oor = validate_integer_range("10", 1, 5)
        self.assertFalse(out_of_range)
        self.assertIn("between", err_oor)

    def test_05_quiz_evaluation_and_persistence(self):
        py_qs = get_questions_by_topic("Python Programming", count=2)
        q1, q2 = py_qs[0], py_qs[1]
        
        user_ans = [(q1, q1.correct_option_index), (q2, (q2.correct_option_index + 1) % len(q2.options))]
        attempt = evaluate_quiz_session("Test Student", "Python Programming", user_ans)

        self.assertEqual(attempt.score, 1)
        self.assertEqual(attempt.total_questions, 2)
        self.assertEqual(attempt.percentage, 50.0)

        attempts = load_attempts()
        self.assertTrue(any(a.attempt_id == attempt.attempt_id for a in attempts))

    def test_06_executive_summary_calculation(self):
        summary = calculate_executive_summary()
        self.assertGreater(summary.total_attempts, 0)
        self.assertGreaterEqual(summary.overall_average_score, 0.0)

    def test_07_bulk_import_csv(self):
        csv_sample = """id,topic,category,question_text,options,correct_option_index,explanation,difficulty
IMP001,Python Programming,Syntax,What is print()?,Print Output | Read Input,0,Prints to console,Easy
"""
        imported, total, errors = bulk_import_questions_csv(csv_sample)
        self.assertEqual(imported, 1)

if __name__ == "__main__":
    unittest.main()

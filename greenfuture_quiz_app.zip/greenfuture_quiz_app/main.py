import os
import sys
import subprocess
from pathlib import Path

# Ensure root path is in sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from src.cli import main_cli

def main():
    print("=" * 65)
    print("   🌱 GREENFUTURE PYTHON QUIZ APPLICATION LAUNCHER 🌱   ")
    print("=" * 65)
    print("Select Interface Mode:")
    print("  [1] Interactive Terminal CLI (Default Command Prompt)")
    print("  [2] Modern Streamlit Web GUI Interface")
    print("  [3] Exit")
    print("-" * 65)

    choice = input("Enter choice (1-3) [default: 1]: ").strip() or "1"

    if choice == "1":
        main_cli()
    elif choice == "2":
        print("\n🚀 Launching Streamlit Web GUI... Press Ctrl+C to stop.\n")
        app_path = BASE_DIR / "app.py"
        try:
            subprocess.run(["streamlit", "run", str(app_path)], check=True)
        except Exception as e:
            print(f"Error launching Streamlit app: {e}")
            print("Make sure streamlit is installed via 'pip install -r requirements.txt'")
    elif choice == "3":
        print("Goodbye!")
    else:
        print("Invalid option. Launching CLI mode...")
        main_cli()

if __name__ == "__main__":
    main()
